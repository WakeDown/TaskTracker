﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TaskTracker.Objects
{
    public enum AdGroup
    {
        None,
            TaskTrackerAdmin,
            TaskTrackerManager,
            TaskTrackerProg
    }
}